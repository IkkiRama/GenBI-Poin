<?php

namespace App\Filament\Resources\PenilaianDeputiQuestionResource\Pages;

use App\Filament\Resources\PenilaianDeputiQuestionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePenilaianDeputiQuestion extends CreateRecord
{
    protected static string $resource = PenilaianDeputiQuestionResource::class;
}
