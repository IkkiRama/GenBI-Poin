<?php

namespace App\Filament\Resources\PenilaianDeputiAnswerResource\Pages;

use App\Filament\Resources\PenilaianDeputiAnswerResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePenilaianDeputiAnswer extends CreateRecord
{
    protected static string $resource = PenilaianDeputiAnswerResource::class;
}
