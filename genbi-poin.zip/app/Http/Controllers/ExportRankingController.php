<?php

namespace App\Http\Controllers;

use PDF;
use Illuminate\Http\Request;
use App\Filament\Pages\Ranking;

class ExportRankingController extends Controller
{
    public function exportRanking(Request $request)
    {
        $month = $request->input('month'); // Ambil bulan dari request jika ada
        $komsat = $request->input('komsat'); // Ambil komsat dari request jika ada

        $rankingPage = new Ranking();
        $ranking = $rankingPage->getRanking($komsat, $month); // Ambil data sesuai bulan dan komsat

        $pdf = PDF::loadView('pdf.ranking', compact('ranking'));

        return $pdf->download('ranking.pdf');
    }

}
