<!DOCTYPE html>
<html>
<head>
    <title>Balasan Pesan Anda</title>
</head>
<body>
    <h1>Halo!</h1>
    <p>Ini adalah balasan dari pesan yang Anda kirimkan:</p>
    <p>{{ $emailMessage }}</p>
    <p>Terima kasih.</p>
</body>
</html>
