<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ranking Deputi PDF</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            color: #333;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .no-data {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
            color: #666;
        }
    </style>
</head>
<body>
    <h1>Ranking Deputi</h1>
    <table>
        <thead>
            <tr>
                <th>Nama</th>
                <th>Komsat</th>
                <th>Bidang</th>
                <th>Total Poin</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($ranking as $rank)
                <tr>
                    <td>{{ $rank['name'] }}</td>
                    <td>{{ $rank['komsat'] }}</td>
                    <td>{{ $rank['bidang'] }}</td>
                    <td>{{ $rank['total_points'] }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
