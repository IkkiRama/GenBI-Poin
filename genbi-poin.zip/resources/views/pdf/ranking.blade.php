<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ranking Member</title>
    <style>
        /* Tailwind-like styling manually included */
        body {
            font-family: 'Helvetica', sans-serif;
            font-size: 12px;
            line-height: 1.5;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th {
            padding: 10px;
            background-color: #f3f4f6;
            text-align: left;
            border-bottom: 1px solid #d1d5db;
        }
        td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .text-center {
            text-align: center;
        }
        .font-bold {
            font-weight: bold;
        }
        .bg-gray-100 {
            background-color: #f3f4f6;
        }
        .border-gray {
            border-color: #d1d5db;
        }
    </style>
</head>
<body>
    <h1 class="font-bold text-center">Ranking Member</h1>

    <table class="table-auto">
        <thead>
            <tr>
                <th class="px-4 py-2">Name</th>
                <th class="px-4 py-2">Komsat</th>
                <th class="px-4 py-2">Bidang</th>
                <th class="px-4 py-2">Total Poin</th>
            </tr>
        </thead>
        <tbody>
            @foreach($ranking as $rank)
                <tr class="{{ $loop->even ? 'bg-gray-100' : '' }}">
                    <td class="px-4 py-2">{{ $rank['name'] }}</td>
                    <td class="px-4 py-2">{{ $rank['komsat'] }}</td>
                    <td class="px-4 py-2">{{ $rank['bidang'] }}</td>
                    <td class="px-4 py-2">{{ $rank['total_points'] }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>



{{-- <!DOCTYPE html>
<html>
<head>
    <title>Ranking PDF</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Ranking Absensi & Kegiatan</h1>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Komsat</th>
                <th>Bidang</th>
                <th>Total Poin</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($ranking as $rank)
                <tr>
                    <td>{{ $rank['name'] }}</td>
                    <td>{{ $rank['komsat'] }}</td>
                    <td>{{ $rank['bidang'] }}</td>
                    <td>{{ $rank['total_points'] }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html> --}}
