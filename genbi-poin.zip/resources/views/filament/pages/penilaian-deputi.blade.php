<x-filament-panels::page>
    <livewire:penilaian-deputi :penilaianId="$penilaianId"/>
</x-filament-panels::page>
