<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                colors: {
                    clifford: '#da373d',
                }
                }
            }
        }
    </script>

    <style type="text/tailwindcss">
        @layer utilities {
        .content-auto {
            content-visibility: auto;
        }
        }
    </style>
    <style>
        /* Gaya untuk container tab */
        .overflow-x-auto {
            overflow-x: auto;
            scrollbar-width: thin;
        }

        .overflow-x-auto::-webkit-scrollbar {
            height: 8px;
        }

        .overflow-x-auto::-webkit-scrollbar-thumb {
            background-color: rgba(29, 78, 216, 0.5);
            border-radius: 10px;
        }

        .overflow-x-auto::-webkit-scrollbar-track {
            background: rgba(229, 231, 235, 0.5);
        }
    </style>

    
    <h2 class="text-lg font-semibold">Filter Komsat</h2>

    <div class="flex space-x-4">
        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['class' => 'px-4 py-2 rounded
                '.e($this->isActiveKomsat === null ? 'bg-blue-600' : 'bg-white').'

                hover:bg-blue-700 focus:outline-none transition-colors duration-300 ease-in-out','wire:click' => 'filterByKomsat(null)','color' => ''.e($this->isActiveKomsat === null ? 'primary' : 'gray').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'px-4 py-2 rounded
                '.e($this->isActiveKomsat === null ? 'bg-blue-600' : 'bg-white').'

                hover:bg-blue-700 focus:outline-none transition-colors duration-300 ease-in-out','wire:click' => 'filterByKomsat(null)','color' => ''.e($this->isActiveKomsat === null ? 'primary' : 'gray').'']); ?>
            Semua Komsat
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['class' => 'px-4 py-2 rounded
                '.e($this->isActiveKomsat === 'unsoed' ? 'bg-blue-600' : 'bg-white').'

                hover:bg-blue-700 focus:outline-none transition-colors duration-300 ease-in-out','wire:click' => 'filterByKomsat(\'unsoed\')','color' => ''.e($this->isActiveKomsat === 'unsoed' ? 'primary' : 'gray').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'px-4 py-2 rounded
                '.e($this->isActiveKomsat === 'unsoed' ? 'bg-blue-600' : 'bg-white').'

                hover:bg-blue-700 focus:outline-none transition-colors duration-300 ease-in-out','wire:click' => 'filterByKomsat(\'unsoed\')','color' => ''.e($this->isActiveKomsat === 'unsoed' ? 'primary' : 'gray').'']); ?>
            Unsoed
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['class' => 'px-4 py-2 rounded
                '.e($this->isActiveKomsat === 'ump' ? 'bg-blue-600' : 'bg-white').'

                hover:bg-blue-700 focus:outline-none transition-colors duration-300 ease-in-out','wire:click' => 'filterByKomsat(\'ump\')','color' => ''.e($this->isActiveKomsat === 'ump' ? 'primary' : 'gray').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'px-4 py-2 rounded
                '.e($this->isActiveKomsat === 'ump' ? 'bg-blue-600' : 'bg-white').'

                hover:bg-blue-700 focus:outline-none transition-colors duration-300 ease-in-out','wire:click' => 'filterByKomsat(\'ump\')','color' => ''.e($this->isActiveKomsat === 'ump' ? 'primary' : 'gray').'']); ?>
            UMP
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['class' => 'px-4 py-2 rounded
                '.e($this->isActiveKomsat === 'uin' ? 'bg-blue-600' : 'bg-white').'

                hover:bg-blue-700 focus:outline-none transition-colors duration-300 ease-in-out','wire:click' => 'filterByKomsat(\'uin\')','color' => ''.e($this->isActiveKomsat === 'uin' ? 'primary' : 'gray').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'px-4 py-2 rounded
                '.e($this->isActiveKomsat === 'uin' ? 'bg-blue-600' : 'bg-white').'

                hover:bg-blue-700 focus:outline-none transition-colors duration-300 ease-in-out','wire:click' => 'filterByKomsat(\'uin\')','color' => ''.e($this->isActiveKomsat === 'uin' ? 'primary' : 'gray').'']); ?>
            UIN
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
    </div>

    
    <h2 class="text-lg font-semibold">Filter Bulan</h2>
    <div class="overflow-x-auto">
        <div class="flex min-w-max ">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->getTabs(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['class' => 'px-4 py-2 rounded
                        '.e($this->isActiveMonth === $month ? 'bg-blue-600' : 'bg-white').'

                        hover:bg-blue-700 focus:outline-none transition-colors duration-300 ease-in-out','wire:click' => 'filterByMonth('.e($month).')','color' => ''.e($this->isActiveMonth === $month ? 'primary' : 'gray').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'px-4 py-2 rounded
                        '.e($this->isActiveMonth === $month ? 'bg-blue-600' : 'bg-white').'

                        hover:bg-blue-700 focus:outline-none transition-colors duration-300 ease-in-out','wire:click' => 'filterByMonth('.e($month).')','color' => ''.e($this->isActiveMonth === $month ? 'primary' : 'gray').'']); ?>
                    <?php echo e($label); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>


    
    <!--[if BLOCK]><![endif]--><?php if($ranking->isNotEmpty()): ?>
        <table class="table-auto w-full mt-6 bg-white rounded-lg shadow-md">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-4 py-2 text-left text-sm font-semibold text-gray-600">Nama</th>
                    <th class="px-4 py-2 text-left text-sm font-semibold text-gray-600">Komsat</th>
                    <th class="px-4 py-2 text-left text-sm font-semibold text-gray-600">Bidang</th>
                    <th class="px-4 py-2 text-left text-sm font-semibold text-gray-600">Total Poin</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ranking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-white border-b">
                        <td class="px-4 py-2 text-sm font-medium text-gray-900"><?php echo e($rank['name']); ?></td>
                        <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($rank['komsat']); ?></td>
                        <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($rank['bidang']); ?></td>
                        <td class="px-4 py-2 text-sm font-semibold text-gray-900"><?php echo e($rank['total_points']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    <?php else: ?>
        <p class="mt-4 text-gray-500">Tidak ada data untuk ditampilkan.</p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <div class="">
        <a href="<?php echo e(route('export.ranking', ['month' => $isActiveMonth, 'komsat' => $isActiveKomsat])); ?>" target="_blank" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Export to PDF</a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\genbi-poin\resources\views/filament/pages/ranking.blade.php ENDPATH**/ ?>